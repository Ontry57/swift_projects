//
//  Group.swift
//  WeatherApp
//
//  Created by korolev-ap on 06.08.2020.
//  Copyright © 2020 Ontry. All rights reserved.
//

import Foundation

struct Group {
    let name: String
    let imageName: String
}
