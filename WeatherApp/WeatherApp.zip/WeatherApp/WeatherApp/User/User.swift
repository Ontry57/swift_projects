import Foundation

struct CurrentUser {
    var name: String
    var age: Int
    var avatar: String
}

